from django.contrib import admin
from .models import Applicant, Criteria

# Register your models here.

admin.site.register(Applicant)
admin.site.register(Criteria)
