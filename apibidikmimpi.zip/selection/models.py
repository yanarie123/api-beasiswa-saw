from django.db import models

class Applicant(models.Model):
    email = models.EmailField(unique=True)
    name = models.CharField(max_length=100)
    password = models.CharField(max_length=255)
    average_score = models.FloatField()
    parent_income = models.FloatField()
    dependents = models.IntegerField()
    decent_house = models.IntegerField(choices=[(1, 'Sangat Layak'), (2, 'Layak'), (3, 'Cukup'), (4, 'Kurang Layak'), (5, 'Tidak Layak')])
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

class Criteria(models.Model):
    name = models.CharField(max_length=100)
    weight = models.FloatField()
    is_benefit = models.BooleanField(default=True)
