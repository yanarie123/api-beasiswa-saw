from rest_framework import viewsets
from rest_framework.views import APIView
from rest_framework.response import Response
from .models import Applicant, Criteria
from .serializers import ApplicantSerializer, CriteriaSerializer

class ApplicantViewSet(viewsets.ModelViewSet):
    queryset = Applicant.objects.all()
    serializer_class = ApplicantSerializer

class CriteriaViewSet(viewsets.ModelViewSet):
    queryset = Criteria.objects.all()
    serializer_class = CriteriaSerializer
    

class RankingView(APIView):
    def get(self, request):
        # Mengambil data pendaftar dan kriteria
        applicants = Applicant.objects.all()
        criteria = Criteria.objects.all()

        # Normalisasi data
        normalized_data = []
        for applicant in applicants:
            norm = []
            for criterion in criteria:
                # Ambil nilai dari atribut dinamis
                value = getattr(applicant, criterion.name)

                # Normalisasi untuk Benefit
                if criterion.is_benefit:
                    norm.append(value / max([getattr(a, criterion.name) for a in applicants]))
                # Normalisasi untuk Cost
                else:
                    norm.append(min([getattr(a, criterion.name) for a in applicants]) / value)
            normalized_data.append(norm)

        # Menghitung skor
        scores = []
        for norm in normalized_data:
            score = sum([n * c.weight for n, c in zip(norm, criteria)])
            scores.append(score)

        # Mengurutkan hasil
        results = sorted(zip(applicants, scores), key=lambda x: x[1], reverse=True)

        # Format hasil
        ranking = []
        for index, (applicant, score) in enumerate(results, 1):
            ranking.append({
                "rank": index,
                "name": applicant.name,
                "email": applicant.email,
                "average_score": applicant.average_score,
                "parent_income": applicant.parent_income,
                "dependents": applicant.dependents,
                "decent_house": dict(Applicant._meta.get_field('decent_house').choices)[applicant.decent_house],
                "score": score,
            })

        return Response(ranking)
