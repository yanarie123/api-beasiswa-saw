from django.urls import path, include
from rest_framework.routers import DefaultRouter
from selection.views import ApplicantViewSet, CriteriaViewSet, RankingView
from django.contrib import admin

router = DefaultRouter()
router.register(r'applicants', ApplicantViewSet)
router.register(r'criteria', CriteriaViewSet)

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', include(router.urls)),
    path('api/auth/', include('selection.auth_views')),
    path('api/ranking/', RankingView.as_view(), name='ranking'),  # Endpoint untuk peringkat
]